
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package mahajana.bookshop;

import com.sun.glass.events.KeyEvent;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Vector;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import net.sf.jasperreports.engine.JRException;
import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.jasperreports.engine.design.JasperDesign;
import net.sf.jasperreports.engine.xml.JRXmlLoader;
import net.sf.jasperreports.view.JasperViewer;

/**
 *
 * @author user
 */
public class GRN extends javax.swing.JFrame {

    /**
     * Creates new form GRN
     */
    public GRN() {
        initComponents();
        Connect(); 
        Orders();
   
    }
    
    
    
     //create connection
    Connection con;
    PreparedStatement pst;
    PreparedStatement pst1;
    PreparedStatement pst2;
    PreparedStatement pst3;
    DefaultTableModel df ;
    ResultSet rs;
    
    public void Connect()
    {
        try{
            
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mahajana_bookshop","root","");
        
          
        }catch(ClassNotFoundException ex){
            
        } catch (SQLException ex) {
            Logger.getLogger(StockHome.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
   
    
    public void Orders()
   {
        try {
            pst = con.prepareStatement("select orderID from order_item  ");
            rs = pst.executeQuery();
            
            txtOrderID.removeAllItems();
            
            while(rs.next())
            {
                txtOrderID.addItem(rs.getString("orderID"));
            }
  
        } catch (SQLException ex) {
            Logger.getLogger(GRN.class.getName()).log(Level.SEVERE, null, ex);
        }
       
   }
    
    
    public void purchase()
    {
       int pcost = Integer.parseInt(txtCost.getText());
       int paccqty = Integer.parseInt(txtAccQty.getText());
       
       int tot = pcost * paccqty;
       
       df = (DefaultTableModel)jTable2.getModel();
       df.addRow(new Object[]
           {
                txtOrderID.getSelectedItem(),
                txtItemID.getText(),
                txtItemName.getText(),
                txtCost.getText(),
                txtAccQty.getText(),
                tot      
            });
 
       int sum = 0;
       
       for(int i = 0; i<jTable2.getRowCount();i++)
       {
           sum = sum + Integer.parseInt(jTable2.getValueAt(i, 5).toString());
       }
               
       txtTotCost.setText(String.valueOf(sum));
  
       
       
        //clear the fields
        txtItemID.setText("");
        txtItemName.setText("");
        txtCost.setText("");
        txtReqQty.setText("");
        txtRecQty.setText("");
        txtDamQty.setText("");
        txtAccQty.setText("");
        
       
    }
    
    
    public void add()
   {
        try {
            DateTimeFormatter dt = DateTimeFormatter.ofPattern("yyyy/MM/dd");
            LocalDateTime now = LocalDateTime.now();
            String date = dt.format(now);
            
            String poid = (String) txtOrderID.getSelectedItem();
            String subtotal = txtTotCost.getText();
            String pay = txtPay.getText();
            String bal = txtBal.getText();
            int lastid = 0; //last insert id
            
            
            String query1 = "insert into purchase(date,subTotal,pay,balance) values (?,?,?,?)";
            pst = con.prepareStatement(query1,Statement.RETURN_GENERATED_KEYS);

            pst.setString(1, date);
            pst.setString(2, subtotal);
            pst.setString(3, pay);
            pst.setString(4, bal);
            pst.executeUpdate();
            
            rs = pst.getGeneratedKeys();
            
            if(rs.next())
            {
                lastid = rs.getInt(1);
            }
            
            int rows = jTable2.getRowCount();
            
            
            
            String query2 = "insert into purchaseitem(purid,orderID,itemID,itemName,costPrice,qtyAccepted,total) values (?,?,?,?,?,?,?)";
            
            pst1 = con.prepareStatement(query2);
            
            int puid = 1;
            String pid;
            String pname;
            String pcost;
            String paccqty;
            int total = 0;
            
       
            for(int i = 0; i<jTable2.getRowCount();i++)
            {
                poid = (String)jTable2.getValueAt(i, 0);
                pid = (String)jTable2.getValueAt(i, 1);
                pname = (String)jTable2.getValueAt(i, 2);
                pcost = (String)jTable2.getValueAt(i, 3);
                paccqty = (String)jTable2.getValueAt(i,4);
                total = (int)jTable2.getValueAt(i, 5);
                
                pst1.setInt(1, lastid);
                pst1.setInt(2, puid);
                pst1.setString(2, poid);
                pst1.setString(3, pid);
                pst1.setString(4, pname);
                pst1.setString(5, pcost);
                pst1.setString(6, paccqty);
                pst1.setInt(7, total);
                pst1.executeUpdate();  
            }
              
            
            // increment products
            String query3 = "update product set qty = qty+ ? where itemID = ?";
            pst2 = con.prepareStatement(query3);
            
            for(int i = 0; i<jTable2.getRowCount();i++)
            {
                pid = (String)jTable2.getValueAt(i, 1);
                paccqty = (String)jTable2.getValueAt(i, 4);
                
                
                pst2.setString(1, paccqty);
                pst2.setString(2, pid);
                pst2.executeUpdate();  
            }
           
            // increment products
             String query4 = "update order_item set qtyRequest = qtyRequest- ? where OrderID = ?";
            pst2 = con.prepareStatement(query4);
            
            for(int i = 0; i<jTable2.getRowCount();i++)
            {
                poid = (String)jTable2.getValueAt(i, 0);
                paccqty = (String)jTable2.getValueAt(i, 4);
                
                
                pst2.setString(1, paccqty);
                pst2.setString(2, poid);
                pst2.executeUpdate();  
            }
            
            
            JOptionPane.showMessageDialog(this, "Purchase Completed");
            
            HashMap m = new HashMap();
            m.put("InvoiceNo", lastid);
            
            try {
                JasperDesign jdesign = JRXmlLoader.load("C:\\Users\\user\\Desktop\\Mahajana_bookshop(Updated File)\\Mahajana Bookshop\\Mahajana Bookshop\\src\\mahajana\\bookshop\\PurchaseInvoice.jrxml");
                JasperReport jreport = JasperCompileManager.compileReport(jdesign);
                
                JasperPrint jprint = JasperFillManager.fillReport(jreport, m , con);
                
                JasperViewer.viewReport(jprint);
                
            } catch (JRException ex) {
                Logger.getLogger(GRN.class.getName()).log(Level.SEVERE, null, ex);
            }
           
            
            txtTotCost.setText("");
            txtPay.setText("");
            txtBal.setText("");
            
        } catch (SQLException ex) {
            Logger.getLogger(GRN.class.getName()).log(Level.SEVERE, null, ex);
            JOptionPane.showMessageDialog(this, "Purchase Not Completed");
        }
       
       
   }
   
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txtRecQty = new javax.swing.JTextField();
        txtDamQty = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        txtOrderID = new javax.swing.JComboBox<>();
        jButton2 = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txtReqQty = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txtCost = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txtAccQty = new javax.swing.JTextField();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTable2 = new javax.swing.JTable();
        jLabel11 = new javax.swing.JLabel();
        txtTotCost = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        txtPay = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        txtBal = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtItemID = new javax.swing.JTextField();
        txtItemName = new javax.swing.JTextField();
        add = new javax.swing.JButton();
        jButton1 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 102));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 30)); // NOI18N
        jLabel1.setText("Good Receiving Notice");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(27, 20, 363, 45));

        jLabel6.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel6.setText("Request Qty");
        jPanel1.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 90, -1, -1));

        jLabel7.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel7.setText("Received Qty");
        jPanel1.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 150, -1, -1));
        jPanel1.add(txtRecQty, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 150, 144, 30));

        txtDamQty.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtDamQtyKeyReleased(evt);
            }
        });
        jPanel1.add(txtDamQty, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 210, 140, 30));

        jLabel8.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel8.setText("Rejected Qty");
        jPanel1.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 220, 100, -1));

        txtOrderID.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtOrderIDKeyReleased(evt);
            }
        });
        jPanel1.add(txtOrderID, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 140, 100, 30));

        jButton2.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton2.setText("LOGOUT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(860, 20, -1, -1));

        jLabel9.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel9.setText("OrderID");
        jPanel1.add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 100, -1, -1));
        jPanel1.add(txtReqQty, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 90, 140, 30));

        jLabel2.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel2.setText("Cost Price");
        jPanel1.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 220, -1, -1));
        jPanel1.add(txtCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 210, 130, 30));

        jLabel3.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel3.setText("Accepted Qty");
        jPanel1.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(480, 280, -1, -1));
        jPanel1.add(txtAccQty, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 270, 140, 30));

        jTable2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "OrderID", "ItemID", "ItemName", "CostPrice", "Accepted Qty", "Total"
            }
        ));
        jScrollPane1.setViewportView(jTable2);

        jPanel1.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(120, 350, 770, 150));

        jLabel11.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel11.setText("Total Cost");
        jPanel1.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 550, 90, -1));

        txtTotCost.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(txtTotCost, new org.netbeans.lib.awtextra.AbsoluteConstraints(150, 540, 160, 30));

        jLabel14.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel14.setText("Payment");
        jPanel1.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 540, 90, 20));

        txtPay.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jPanel1.add(txtPay, new org.netbeans.lib.awtextra.AbsoluteConstraints(450, 540, 160, 30));

        jLabel13.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel13.setText("Balance");
        jPanel1.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(680, 540, 90, -1));

        txtBal.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        txtBal.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txtBalActionPerformed(evt);
            }
        });
        jPanel1.add(txtBal, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 540, 160, 30));

        jLabel4.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel4.setText("ItemID");
        jPanel1.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 90, -1, -1));

        jLabel5.setFont(new java.awt.Font("Tahoma", 0, 16)); // NOI18N
        jLabel5.setText("ItemName");
        jPanel1.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(190, 150, -1, -1));
        jPanel1.add(txtItemID, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 90, 130, 30));
        jPanel1.add(txtItemName, new org.netbeans.lib.awtextra.AbsoluteConstraints(300, 150, 130, 30));

        add.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        add.setText("ADD");
        add.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addActionPerformed(evt);
            }
        });
        jPanel1.add(add, new org.netbeans.lib.awtextra.AbsoluteConstraints(810, 260, 90, 30));

        jButton1.setFont(new java.awt.Font("Tahoma", 0, 14)); // NOI18N
        jButton1.setText("Print Invoice");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(580, 600, -1, 30));

        jButton6.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        jButton6.setText("BACK");
        jButton6.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton6ActionPerformed(evt);
            }
        });
        jPanel1.add(jButton6, new org.netbeans.lib.awtextra.AbsoluteConstraints(760, 20, 80, -1));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 973, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 657, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void txtOrderIDKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtOrderIDKeyReleased
        // TODO add your handling code here:
        if(evt.getKeyCode() == KeyEvent.VK_ENTER)
        {
            String poid = txtOrderID.getSelectedItem().toString();

            try {
                Class.forName("com.mysql.jdbc.Driver");
                con = DriverManager.getConnection("jdbc:mysql://localhost:3306/mahajana_bookshop","root","");

   
                pst = con.prepareStatement("select * from order_item where orderID = ?");
                pst.setString(1, poid);

                rs = pst.executeQuery();

                if(rs.next() == false)
                {
                    JOptionPane.showMessageDialog(this, "Not Found");

                }
                else
                {
                    String pid = rs.getString("itemID");
                    String pname = rs.getString("itemName");
                    String pcost = rs.getString("costPrice");
                    String preqty = rs.getString("qtyRequest");
                
                    txtItemID.setText(pid.trim());
                    txtItemName.setText(pname.trim());
                    txtCost.setText(pcost.trim());
                    txtReqQty.setText(preqty.trim());
                    txtRecQty.requestFocus();


                }

            } catch (ClassNotFoundException ex) {
                Logger.getLogger(Item.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(Item.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
    }//GEN-LAST:event_txtOrderIDKeyReleased

    private void txtDamQtyKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtDamQtyKeyReleased
         if(evt.getKeyCode() == KeyEvent.VK_ENTER)
        {
         
            int prece = Integer.parseInt(txtRecQty.getText());
            int pdam = Integer.parseInt(txtDamQty.getText());
            
            int paccqty = prece - pdam;
            txtAccQty.setText(""+paccqty);
            txtAccQty.requestFocus();
        }
    }//GEN-LAST:event_txtDamQtyKeyReleased

    private void txtBalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txtBalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txtBalActionPerformed

    private void addActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addActionPerformed
        // TODO add your handling code here:
        
        purchase();
        
    }//GEN-LAST:event_addActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
          // TODO add your handling code here:
        int pay = Integer.parseInt(txtPay.getText());
        int subtotal = Integer.parseInt(txtTotCost.getText());
        int bal = pay - subtotal;
        
        txtBal.setText(String.valueOf(bal));
        
        add();
        
        
        //clear thhe fields
        txtItemName.setText("");
        txtCost.setText("");
        txtAccQty.setText("");
        
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
            setVisible(false);
            Login object = new Login();
            object.setVisible(true);
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton6ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton6ActionPerformed
        // TODO add your handling code here:
        setVisible(false);
        StockHome object = new StockHome();
        object.setVisible(true);
    }//GEN-LAST:event_jButton6ActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(GRN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(GRN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(GRN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(GRN.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new GRN().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton add;
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton6;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTable jTable2;
    private javax.swing.JTextField txtAccQty;
    private javax.swing.JTextField txtBal;
    private javax.swing.JTextField txtCost;
    private javax.swing.JTextField txtDamQty;
    private javax.swing.JTextField txtItemID;
    private javax.swing.JTextField txtItemName;
    private javax.swing.JComboBox<String> txtOrderID;
    private javax.swing.JTextField txtPay;
    private javax.swing.JTextField txtRecQty;
    private javax.swing.JTextField txtReqQty;
    private javax.swing.JTextField txtTotCost;
    // End of variables declaration//GEN-END:variables
}
